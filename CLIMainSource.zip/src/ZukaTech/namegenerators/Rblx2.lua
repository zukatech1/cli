-- rblx2 (final weighted hybrid build)

local util = require("ZukaTech.util")
local _runSalt = 0

-- RNG
local function _bumpSeed(seed)
	return (seed * 1664525 + 1013904223) % 0x7FFFFFFF
end

local function _saltedSeed(id)
	local s = (id + _runSalt) % 0x7FFFFFFF
	s = _bumpSeed(s); s = _bumpSeed(s); s = _bumpSeed(s)
	return s
end

local function _randInt(seed, range)
	seed = _bumpSeed(seed); seed = _bumpSeed(seed)
	return seed % range, seed
end

-- weighted picker
local function weightedPick(pool, seed)
	seed = _bumpSeed(seed)
	local total = 0
	for _, e in ipairs(pool) do total += e.weight or 1 end
	local roll = (_bumpSeed(seed) % total) + 1
	for _, e in ipairs(pool) do
		roll -= (e.weight or 1)
		if roll <= 0 then return e.value end
	end
	return pool[#pool].value
end

-- weighted pools (realistic Roblox feel)
local prefixes = {
	{value="Service",weight=5},{value="Remote",weight=5},{value="Player",weight=4},
	{value="Module",weight=4},{value="Script",weight=3},{value="Network",weight=3},
	{value="Core",weight=2},{value="Render",weight=1}
}

local middles = {
	{value="Handler",weight=5},{value="Manager",weight=5},{value="Controller",weight=4},
	{value="Dispatcher",weight=3},{value="Collector",weight=2}
}

local suffixes = {
	{value="Impl",weight=5},{value="Core",weight=5},{value="Base",weight=4},
	{value="Util",weight=3},{value="Helper",weight=2}
}

local service_suffixes = {
	{value="Service",weight=4},{value="Controller",weight=3},
	{value="Provider",weight=2},{value="Manager",weight=2}
}

local snake_parts = {
	{value="instance",weight=5},{value="remote",weight=5},{value="script",weight=4},
	{value="player",weight=4},{value="character",weight=3},{value="data",weight=2}
}

local short_bases = {
	{value="n",weight=2},{value="v",weight=2},{value="k",weight=1},
	{value="t",weight=1},{value="s",weight=1},{value="p",weight=1}
}

-- hex builder
local function buildHex(seed)
	local parts = {}
	for i=1,(_bumpSeed(seed)%3)+2 do
		local val = (_bumpSeed(seed+i*1337) % 0xFFFF)
		parts[i] = string.format("0x%04X", val)
	end
	return "_"..table.concat(parts,"_")
end

-- letter builder (fallback cryptic)
local function buildLetter(seed)
	local len = (_bumpSeed(seed)%6)+8
	local chars = {}
	for i=1,len do
		local c = string.char((_bumpSeed(seed+i*17)%26)+97)
		chars[i]=c
	end
	return table.concat(chars)
end

-- hybrids
local function buildCamelHybrid(seed)
	local name = weightedPick(prefixes,seed)

	if (_bumpSeed(seed)%100)<60 then
		name = name .. weightedPick(middles,seed+7)
	end

	if (_bumpSeed(seed)%100)<40 then
		name = name .. weightedPick(suffixes,seed+13)
	end

	if (_bumpSeed(seed)%100)<25 then
		name = name .. weightedPick(service_suffixes,seed+19)
	end

	-- subtle hex injection
	if (_bumpSeed(seed)%100)<30 then
		name = name .. buildHex(seed+23)
	end

	return name
end

local function buildSnakeHybrid(seed)
	local parts = {}
	local count = (_bumpSeed(seed)%2)+2

	for i=1,count do
		parts[i]=weightedPick(snake_parts,seed+i*17)
	end

	if count>1 and (_bumpSeed(seed)%100)<25 then
		parts[2] = parts[2] .. buildHex(seed+31)
	end

	return table.concat(parts,"_")
end

local function buildShortHybrid(seed,scopeKey,counters)
	counters[scopeKey]=(counters[scopeKey] or 0)+1
	local name = weightedPick(short_bases,seed)..tostring(counters[scopeKey])

	if (_bumpSeed(seed)%100)<10 then
		name = name .. buildHex(seed+55)
	end

	return name
end

-- state
local _usedGlobal = {}
local _usedScope  = {}
local _counters   = {}

local function isUsed(name,scope)
	return _usedGlobal[name] or (_usedScope[scope] and _usedScope[scope][name])
end

local function markUsed(name,scope)
	_usedGlobal[name]=true
	_usedScope[scope]=_usedScope[scope] or {}
	_usedScope[scope][name]=true
end

local function reset()
	_usedGlobal = {}
	_usedScope  = {}
	_counters   = {}
end

local function scopeKey(scope)
	if type(scope)=="table" then return tostring(scope) end
	return tostring(scope)
end

local function scopeLevel(scope)
	if type(scope)=="table" then return scope.level or scope.depth or 0 end
	return tonumber(scope) or 0
end

-- style chooser
local function chooseStyle(level,seed)
	if (_bumpSeed(seed)%100)<20 then
		return (_bumpSeed(seed)%2==0) and "hex" or "letter"
	end

	if level>=6 then
		return (_bumpSeed(seed)%2==0) and "snake" or "camel"
	elseif level>=3 then
		return "short"
	else
		return "camel"
	end
end

-- main
local function generateName(id,scope,originalName)
	local key   = scopeKey(scope)
	local level = scopeLevel(scope)
	local seed  = _saltedSeed(id)
	local style = chooseStyle(level,seed)

	local name, attempts = nil, 0

	repeat
		if style=="camel" then
			name = buildCamelHybrid(seed)
		elseif style=="snake" then
			name = buildSnakeHybrid(seed)
		elseif style=="short" then
			name = buildShortHybrid(seed,key,_counters)
		elseif style=="hex" then
			name = buildHex(seed)
		elseif style=="letter" then
			name = buildLetter(seed)
		end

		if isUsed(name,key) then
			seed=_bumpSeed(seed)
			name=nil
		end

		attempts+=1
	until name or attempts>128

	if not name then
		name = (originalName or "v")..tostring(id)
	end

	markUsed(name,key)
	return name
end

-- prepare
local function prepare()
	reset()
	local t = (os.time() or 0) % 0x7FFFFFFF
	local c = math.floor(os.clock()*1e6) % 0x7FFFFFFF
	_runSalt = _bumpSeed((t + c) % 0x7FFFFFFF)
end

return {
	generateName = generateName,
	prepare = prepare,
	buildHex = buildHex,
	buildLetter = buildLetter
}