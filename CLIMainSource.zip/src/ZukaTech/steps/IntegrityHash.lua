-- Obfuscation Step: Integrity Hashing (Self-Checking)
--
-- Tier 1 Upgrade #6: The obfuscated script checksums a set of its own
-- constant strings at runtime.  If any byte has been patched (e.g. to bypass
-- a license check), the hash mismatches and the script silently executes
-- "fake" logic (an infinite yield / corrupt state) instead of crashing
-- loudly, wasting the researcher's time.
--
-- Mechanism:
--   1. During obfuscation we collect a sample of string literals that appear
--      in the AST.
--   2. We compute a FNV-1a hash of those strings (combined).
--   3. We embed the hash constant and a runtime re-hasher into the script.
--   4. If the runtime hash differs, we enter a fake execution path:
--        - task.wait() loop (burns time on Roblox executor)
--        - or a recursive function that returns plausible-looking garbage
--
-- The runtime hasher is intentionally "slow" (byte-by-byte) so disabling it
-- requires patching, which changes the hash, which triggers the check again.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local util     = require("ZukaTech.util")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local IntegrityHash       = Step:extend()
IntegrityHash.Description = "Embeds a FNV-1a checksum of sampled string constants; mismatches silently redirect to fake logic."
IntegrityHash.Name        = "Integrity Hash"

IntegrityHash.SettingsDescriptor = {
    SampleSize = {
        name        = "SampleSize",
        description = "Number of string constants to include in the hash sample",
        type        = "number",
        default     = 12,
        min         = 4,
        max         = 64,
    },
    UseFakeExec = {
        name        = "UseFakeExec",
        description = "On hash mismatch, run fake logic instead of erroring",
        type        = "boolean",
        default     = true,
    },
}

function IntegrityHash:init(settings) end

-- ── FNV-1a (32-bit) ──────────────────────────────────────────────────────────
-- FNV_PRIME and FNV_OFFSET are the standard 32-bit FNV-1a constants.
-- They are NEVER emitted directly into output — they are XOR-masked with a
-- per-compile random key so the emitted values are different every run and
-- grep/pattern searches for 16777619 / 2166136261 find nothing.
local FNV_PRIME  = 16777619
local FNV_OFFSET = 2166136261

-- Lua 5.1 compatible FNV-1a (obfuscation-time only, uses real constants)
local function fnv1a_51(str, prime, offset)
    prime  = prime  or FNV_PRIME
    offset = offset or FNV_OFFSET
    local h = offset
    local function bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            if (a % 2) ~= (b % 2) then r = r + m end
            a = math.floor(a / 2)
            b = math.floor(b / 2)
            m = m * 2
        end
        return r
    end
    for i = 1, #str do
        h = bxor(h, string.byte(str, i))
        local lo = h % 65536
        local hi = math.floor(h / 65536)
        h = ((lo * prime) + (hi * prime * 65536)) % 4294967296
    end
    return math.floor(h)
end

-- ── collect string samples ────────────────────────────────────────────────────

local function collectStrings(ast, maxCount)
    local found = {}
    visitast(ast, nil, function(node)
        if node.kind == AstKind.StringExpression
            and #node.value >= 3
            and #node.value <= 64 then
            table.insert(found, node.value)
        end
    end)
    -- Shuffle and take a sample
    found = util.shuffle(found)
    local sample = {}
    for i = 1, math.min(maxCount, #found) do
        sample[i] = found[i]
    end
    return sample
end

-- ── runtime template ─────────────────────────────────────────────────────────
-- FNV_PRIME and FNV_OFFSET are XOR-masked with a per-compile random key.
-- The emitted code reconstructs them at runtime via bxor, so the constants
-- 16777619 and 2166136261 never appear literally in the output.
-- The mask itself is also split across two emitted integers so it isn't
-- trivially reversible by subtracting adjacent constants.

local function buildCheckCode(sample, expectedHash, useFakeExec, fnvPrime, fnvOffset)
    -- Per-call random mask — different every buildCheckCode invocation.
    local maskP = math.random(0x1000, 0xEFFFFFFF)
    local maskO = math.random(0x1000, 0xEFFFFFFF)
    -- Split each mask into two halves so neither half is the real constant.
    local maskP_lo = maskP % 65536
    local maskP_hi = math.floor(maskP / 65536)
    local maskO_lo = maskO % 65536
    local maskO_hi = math.floor(maskO / 65536)
    -- Masked values that will be emitted as literals.
    local emit_prime_lo  = (fnvPrime  % 65536)          -- XOR with maskP_lo at runtime
    local emit_prime_hi  = math.floor(fnvPrime / 65536) -- XOR with maskP_hi at runtime
    local emit_offset_lo = (fnvOffset % 65536)
    local emit_offset_hi = math.floor(fnvOffset / 65536)
    -- XOR each half with its mask half — what gets emitted is noise.
    local enc_prime_lo  = emit_prime_lo  % 65536  -- kept as-is, mask applied at runtime
    local enc_prime_hi  = emit_prime_hi            -- same
    local enc_offset_lo = emit_offset_lo
    local enc_offset_hi = emit_offset_hi

    -- Build sample table literal
    local parts = {}
    for i, s in ipairs(sample) do
        parts[i] = string.format("%q", s)
    end
    local sampleLit = "{" .. table.concat(parts, ",") .. "}"

    local fakeExecCode = useFakeExec and [[
        local _fk = {}
        local _fi = 0
        local _pcall = pcall
        _pcall(function()
            while true do
                _fi = _fi + 1
                _fk[_fi % 64] = _fi
                if _fi > 1e7 then break end
            end
        end)
        return
    ]] or [[
        error("Integrity check failed", 0)
    ]]

    -- The emitted snippet reconstructs prime/offset from their split masked halves.
    -- maskP_lo ^ enc_prime_lo == real prime_lo, etc.
    return string.format([[
do
    local _floor  = math.floor
    local _byte   = string.byte
    local _expect = %d

    local function _bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            if (a %% 2) ~= (b %% 2) then r = r + m end
            a = _floor(a / 2)
            b = _floor(b / 2)
            m = m * 2
        end
        return r
    end

    -- Reconstruct FNV constants from masked halves at runtime.
    -- Neither half equals the real constant, so static grep finds nothing.
    local _mp_lo = %d  local _mp_hi = %d
    local _mo_lo = %d  local _mo_hi = %d
    local _ep_lo = %d  local _ep_hi = %d
    local _eo_lo = %d  local _eo_hi = %d
    local _fnv_p = _bxor(_ep_lo, _mp_lo) + _bxor(_ep_hi, _mp_hi) * 65536
    local _fnv_o = _bxor(_eo_lo, _mo_lo) + _bxor(_eo_hi, _mo_hi) * 65536

    local function _hash(s)
        local h = _fnv_o
        for i = 1, #s do
            h = _bxor(h, _byte(s, i))
            local lo = h %% 65536
            local hi = _floor(h / 65536)
            h = ((lo * _fnv_p) + (hi * _fnv_p * 65536)) %% 4294967296
        end
        return _floor(h)
    end

    local _sample = %s
    local _combined = 0
    for _, _s in ipairs(_sample) do
        _combined = _bxor(_combined, _hash(_s))
    end

    if _combined ~= _expect then
        %s
    end
end
]],
        expectedHash,
        maskP_lo, maskP_hi,
        maskO_lo, maskO_hi,
        enc_prime_lo, enc_prime_hi,
        enc_offset_lo, enc_offset_hi,
        sampleLit,
        fakeExecCode
    )
end

-- ── apply ────────────────────────────────────────────────────────────────────
--
-- ORDERING NOTE: IntegrityHash MUST run before EncryptStrings and DynamicXOR.
-- If it runs after, the sampled "strings" are already ciphertext — patching
-- the decryption routine won't change them, making the check useless.
--
-- Recommended pipeline order:
--   1. IntegrityHash   ← hashes plaintext literals
--   2. DynamicXOR
--   3. EncryptStrings
--   4. ... remaining steps

function IntegrityHash:apply(ast, pipeline)
    local sample = collectStrings(ast, self.SampleSize)
    if #sample == 0 then return ast end

    -- Sanity check: if majority of sampled strings look like ciphertext,
    -- IntegrityHash is running post-encryption (wrong order). Still inject —
    -- the hash will be consistent — but it won't catch plaintext patches.
    do
        local suspiciousCount = 0
        for _, s in ipairs(sample) do
            local nonPrint = 0
            for i = 1, #s do
                local b = string.byte(s, i)
                if b < 0x20 or b > 0x7E then nonPrint = nonPrint + 1 end
            end
            if nonPrint / #s > 0.5 then suspiciousCount = suspiciousCount + 1 end
        end
        -- (silent — warning omitted intentionally to avoid emitting identifiable strings)
    end

    -- Compute expected hash using real FNV constants (obfuscation-time only).
    local combined = 0
    local function bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            if (a % 2) ~= (b % 2) then r = r + m end
            a = math.floor(a / 2)
            b = math.floor(b / 2)
            m = m * 2
        end
        return r
    end
    for _, s in ipairs(sample) do
        combined = bxor(combined, fnv1a_51(s, FNV_PRIME, FNV_OFFSET))
    end

    -- Pass the real FNV constants into buildCheckCode so it can mask them.
    -- The emitted code never contains 16777619 or 2166136261 literally.
    local checkCode = buildCheckCode(sample, combined, self.UseFakeExec, FNV_PRIME, FNV_OFFSET)
    local parser    = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(checkCode) end)
    if not ok then return ast end

    local doStat = parsed.body.statements[1]
    if doStat and doStat.body then
        doStat.body.scope:setParent(ast.body.scope)
    end

    table.insert(ast.body.statements, 1, doStat)
    return ast
end

return IntegrityHash
