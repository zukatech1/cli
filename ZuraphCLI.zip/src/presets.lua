return {
	["1"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "rblx";
		PrettyPrint = true; Seed = 0;
		Steps = {
			{ Name = "Vmify";          Settings = {} };
			{ Name = "EncryptStrings"; Settings = {} };
			{ Name = "SplitStrings"; Settings = {} };
		        { Name = "NumbersToExpressions"; Settings = {} };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };



		};
		Hercules = nil;
	};
	["Weak"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Unicode";
		PrettyPrint = true; Seed = 0;
		Steps = {
			{ Name = "VariableRenamer"; Settings = {} };
			{ Name = "BytecodeEncoder"; Settings = {} };
			


		};
		Hercules = nil;
	};
	["Default"] = {
		LuaVersion = "Lua51"; VarNamePrefix = "_z"; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "Vmify";          Settings = {} };
			{ Name = "EncryptStrings"; Settings = {} };
			{ Name = "DynamicXOR";     Settings = { Treshold = 0.2 } };
			{ Name = "ConstantArray";  Settings = {
				Treshold = 0.75; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 5;
			}};
			{ Name = "InvertedExecution";    Settings = { ChunkSize = 1; RandomiseIds = true; JunkChunks = 4 } };
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = nil;
	};
	["Medium"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "ZukaZalgo";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0;
			}};
			{ Name = "NumbersToExpressions"; Settings = {} };
			{ Name = "WrapInFunction";       Settings = {} };
		};
		Hercules = nil;
	};
	["Strong"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "Vmify";                Settings = {} };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0;
			}};
			{ Name = "NumbersToExpressions"; Settings = {} };
			{ Name = "WrapInFunction";       Settings = {} };
		};
		Hercules = nil;
	};
	["Executor"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "ZukaZalgo";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
			{ Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.6; InjectionsPerBlock = 1 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "Compressor";           Settings = { MinLength = 10 } };
		};
		Hercules = nil;
	};
	["VmifyBC"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Il";
		PrettyPrint = false; Seed = 0;
		Steps = {

			{ Name = "VmifyBC";        Settings = { XorKey = 0; ShuffleOpcodes = true } };
			--{ Name = "BlobCompress";         Settings = {} };



		};
		Hercules = nil;
	};
	["Main"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "Il";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "ShadowRegisters";      Settings = { Density = 0.3; ShadowSize = 20 } };
			{ Name = "Vmify";                Settings = {} };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
			{ Name = "JunkStatements";       Settings = {
				InjectionCount = 2; Treshold = 0.9; TableWriteRatio = 0.5;
				ChainLength = 4; TableWriteCount = 3;
			}};
			{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "Compressor";           Settings = { MinLength = 10 } };
		};
		Hercules = nil;
	};
	["Tier1_BC"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "lI";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "CffIntegrity";         Settings = { TableSize = 7; TrapIndex = 0 } };
			{ Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
			{ Name = "EncryptStrings";       Settings = {} };
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.25 } };
			{ Name = "ShadowRegisters";      Settings = { Density = 0.3; ShadowSize = 20 } };
			{ Name = "VmifyBC";              Settings = { XorKey = 0; ShuffleOpcodes = true } };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
			{ Name = "JunkStatements";       Settings = {
				InjectionCount = 2; Treshold = 0.9; TableWriteRatio = 0.5;
				ChainLength = 4; TableWriteCount = 3;
			}};
			{ Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
			{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
			{ Name = "WrapInFunction";       Settings = {} };
			{ Name = "BlobCompress";         Settings = {} };
		};
		Hercules = nil;
	};
	["NoVmMax"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "DecEsc";
		PrettyPrint = true; Seed = 0;
		Steps = {
			{ Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
			{ Name = "EncryptStrings";       Settings = {} };
			--{ Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
			{ Name = "ConstantsObfuscator";  Settings = {
				ObfuscateNumbers = true; ObfuscateStrings = true;
				MockStringChance = 6; MinAbsValue = 3;
			}};
			{ Name = "ShadowRegisters";      Settings = { Density = 0.35; ShadowSize = 24 } };
			{ Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.75 } };
			{ Name = "ConstantArray";        Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 0;
			}};
			{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
			{ Name = "JunkStatements";       Settings = {
				InjectionCount = 5; Treshold = 0.8; TableWriteRatio = 0.5;
				ChainLength = 3; TableWriteCount = 3;
			}};
			{ Name = "DynamicXOR";           Settings = { Treshold = 0.25 } };
			{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
			{ Name = "WrapInFunction";       Settings = {} };
		};
		Hercules = nil;
	};
	
	["Tier1"] = {
        LuaVersion    = "Lua51";
        VarNamePrefix = "";
        NameGenerator = "func";
        PrettyPrint   = false;
        Seed          = 0;
        Steps = {
            { Name = "Vmify"; Settings = {}; },
            {
                Name = "DynamicXOR";
                Settings = { Treshold = 1; };
            },
            { Name = "EncryptStrings"; Settings = {}; },
            { Name = "AntiTamper"; Settings = { UseDebug = false; }; },
            {
                Name = "IntegrityHash";
                Settings = { SampleSize = 16; UseFakeExec = true; };
            },
            { Name = "Vmify"; Settings = {}; },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold             = 1;
                    StringsOnly          = true;
                    Shuffle              = true;
                    Rotate               = true;
                    LocalWrapperTreshold = 1;
                    LocalWrapperCount    = 3;
                    LocalWrapperArgCount = 12;
                };
            },
            {
                Name = "NumbersToExpressions";
                Settings = { Treshold = 1; InternalTreshold = 0.3; };
            },
            {
                Name = "OpaquePredicates";
                Settings = { Treshold = 0.85; InjectionsPerBlock = 2; };
            },
            {
                Name = "JunkStatements";
                Settings = {
                    InjectionCount  = 2;
                    Treshold        = 0.9;
                    TableWriteRatio = 0.5;
                    ChainLength     = 4;
                    TableWriteCount = 3;
                };
            },
            {
                Name = "AntiDump";
                Settings = { GCInterval = 50; UseEnvProxy = false; };
            },
            {
                Name = "VirtualGlobals";
                Settings = { Treshold = 1; UseNumericKeys = true; };
            },
            {
                Name = "FakeLoopWrap";
                Settings = { Treshold = 0.35; };
            },
            { Name = "WrapInFunction"; Settings = {}; },
        };
    };
	["Luarmor"] = {
        LuaVersion    = "Lua51";
        VarNamePrefix = "";
        NameGenerator = "rblx";
        PrettyPrint   = false;
        Seed          = 0;
        Steps = {
            {
                Name     = "Vmify";
                Settings = {};
            },
            {
                Name     = "EncryptStrings";
                Settings = {};
            },
            {
                Name     = "AntiTamper";
                Settings = { UseDebug = false };
            },
            {
                Name     = "Vmify";
                Settings = {};
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold             = 1;
                    StringsOnly          = false;
                    Shuffle              = true;
                    Rotate               = true;
                    LocalWrapperTreshold = 0;
                };
            },
            {
                Name = "NumbersToExpressions";
                Settings = {
                    Treshold         = 1;
                    InternalTreshold = 0.2;
                };
            },
            {
                Name = "JunkStatements";
                Settings = {
                    InjectionCount  = 4;
                    Treshold        = 0.85;
                    TableWriteRatio = 0.5;
                    ChainLength     = 3;
                    TableWriteCount = 3;
                };
            },
            {
                Name = "DynamicXOR";
                Settings = { Treshold = 0.5; };
            },
            {
                Name = "FakeLoopWrap";
                Settings = {
                    Treshold = 0.30;
                };
            },
            {
                Name     = "WrapInFunction";
                Settings = {};
            },
        };
    };
	["ZuraphMax"] = {
    LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "rblx";
    PrettyPrint = false; Seed = 0;
    Steps = {
        -- [ Anti-analysis guards first, before anything is transformed ]
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };

        -- [ Layer 1: raw string/constant encryption before any structural work ]
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };

        -- [ Dynamic constant decryption: DynamicXOR first pass (fast, broad),
        --   then DynamicDecrypt second pass (Feistel + runtime S-box) on
        --   whatever DynamicXOR missed. Running both layers means an attacker
        --   has to break two independent cipher schemes. ]
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };

        -- [ VM lift: wraps code in a custom bytecode VM ]
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };

        -- [ Constant-level obfuscation: algebraic expression wrapping ]
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 8; MinAbsValue = 5;
        }};

        -- [ Structural obfuscation pass 1: shadow registers + CFG mangling ]
        { Name = "ShadowRegisters";      Settings = { Density = 0.4; ShadowSize = 32 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.6 } };

        -- [ NEW: Dynamic Jumps — re-flattens after StatementFlattener so
        --   functions that were just state-machine'd now also get a runtime-
        --   randomized indirect jump table. Running after StatementFlattener
        --   means the jump table wraps an already-flattened body, doubling
        --   the CFG complexity. ]
        { Name = "DynamicJumps";         Settings = { Threshold = 0.85; PoolSize = 64; MinStatements = 2 } };

        -- [ Second VM lift: the structurally-mangled code goes through Vmify
        --   again so the jump-table dispatch lives inside a VM too ]
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };

        -- [ Constant array extraction + number expression expansion ]
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        }};
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };

        -- [ Junk injection + opaque predicates after structure is set ]
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 1; Treshold = 0.9; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        }};

        -- [ Late anti-dump (second pass catches anything injected above) ]
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };

        -- [ Final wrappers ]
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = false } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.4 } };

        -- [ Inverted Execution: physically flips the top-level dispatch table
        --   so the last chunk of obfuscated code appears first in the file.
        --   Runs after all structural/VM passes so it wraps the already-
        --   hardened output, and before WrapInFunction so the flip is the
        --   outermost visible structure. ]
        --{ Name = "InvertedExecution";    Settings = { ChunkSize = 1; RandomiseIds = true; JunkChunks = 4 } };

        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
	["Luraph"] = {
    LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "rblx";
    PrettyPrint = false; Seed = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.3 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        }};
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.9; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        }};
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
	["HttpGet"] = {
		LuaVersion = "Lua51"; VarNamePrefix = ""; NameGenerator = "rblx";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "EncryptStrings"; Settings = {} };
			{ Name = "DynamicXOR";     Settings = { Treshold = 1 } };
			{ Name = "Vmify";          Settings = {} };
			{ Name = "ConstantArray";  Settings = {
				Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
				LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 8;
			}};
			{ Name = "JunkStatements"; Settings = {
				InjectionCount = 2; Treshold = 0.7; TableWriteRatio = 0.4;
				ChainLength = 2; TableWriteCount = 2;
			}};
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = nil;
	};
	["Debug"] = {
		LuaVersion = "Lua51"; VarNamePrefix = "_z"; NameGenerator = "SegAddr";
		PrettyPrint = false; Seed = 0;
		Steps = {
			{ Name = "VmifyBC";        Settings = { XorKey = 0; ShuffleOpcodes = false } };
			{ Name = "WrapInFunction"; Settings = {} };
		};
		Hercules = nil;
	};
}