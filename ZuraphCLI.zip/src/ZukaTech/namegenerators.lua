return {
	Mangled         = require("ZukaTech.namegenerators.mangled");
	MangledShuffled = require("ZukaTech.namegenerators.mangled_shuffled");
	Il              = require("ZukaTech.namegenerators.Il");
	Number          = require("ZukaTech.namegenerators.number");
	Confuse         = require("ZukaTech.namegenerators.confuse");
	Unicode         = require("ZukaTech.namegenerators.unicode");
	Keywords        = require("ZukaTech.namegenerators.keywords");
	Hex             = require("ZukaTech.namegenerators.hex");
	Ghost           = require("ZukaTech.namegenerators.ghost");
	ZukaWeave       = require("ZukaTech.namegenerators.zukaweave");
	Mirage          = require("ZukaTech.namegenerators.mirage");
	ZukaZalgo       = require("ZukaTech.namegenerators.zukazalgo");
	Braille         = require("ZukaTech.namegenerators.braille");
	Runic           = require("ZukaTech.namegenerators.runic");
	Noise           = require("ZukaTech.namegenerators.noise");
	Phantom         = require("ZukaTech.namegenerators.phantom");
	Sigil           = require("ZukaTech.namegenerators.sigil");
	SegAddr         = require("ZukaTech.namegenerators.segaddr");
	kawaii          = require("ZukaTech.namegenerators.kawaii");
	Boronide        = require("ZukaTech.namegenerators.boronide");
	DecEsc          = require("ZukaTech.namegenerators.decesc");
    RegAsm          = require("ZukaTech.namegenerators.regasm");
	zuka            = require("ZukaTech.namegenerators.Zuka");
	rblx            = require("ZukaTech.namegenerators.Rblx");
	func            = require("ZukaTech.namegenerators.funcs");


}
