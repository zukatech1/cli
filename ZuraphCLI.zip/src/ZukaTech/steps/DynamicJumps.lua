-- Obfuscation Step: Dynamic Jumps
--
-- What "dynamic instruction jumps" means here:
--
--   StatementFlattener converts function bodies to state machines, but the
--   opcode values and dispatch order are STATIC — the same every run.
--   A decompiler that analyzes the output once can reconstruct the CFG forever.
--
--   DynamicJumps re-flattens function bodies so that:
--
--     1. OPCODE VALUES are chosen at RUNTIME from a shuffled pool, not baked
--        in at obfuscation time. Each execution produces different opcode ints,
--        so there is no fixed CFG to analyze.
--
--     2. DISPATCH uses an INDIRECT JUMP TABLE (a Lua table of closures) rather
--        than an if-elseif chain. This breaks pattern-matching decompilers that
--        look for "if state == K then" sequences.
--
--     3. The jump table is BUILT at runtime by selecting random slots from a
--        pre-shuffled opcode pool, so even the table structure varies per run.
--
-- Transformed structure (per function body):
--
--     -- Original:
--     local function f(...)
--         stmt1
--         stmt2
--         stmt3
--     end
--
--     -- Transformed:
--     local function f(...)
--         -- runtime opcode pool: shuffled at each call
--         local _pool = { <N random unique ints shuffled at runtime> }
--         local _s1, _s2, _s3 = _pool[1], _pool[2], _pool[3]
--
--         -- indirect dispatch table: index = opcode, value = handler closure
--         local _jt = {}
--         _jt[_s1] = function(_jt_, _st_, ...)  -- stmt1 then jump to s2
--             stmt1
--             _st_[1] = _s2
--         end
--         _jt[_s2] = function(_jt_, _st_, ...)  -- stmt2 then jump to s3
--             stmt2
--             _st_[1] = _s3
--         end
--         _jt[_s3] = function(_jt_, _st_, ...)  -- stmt3 then terminate
--             stmt3
--             _st_[1] = nil
--         end
--
--         local _st = { _s1 }                   -- mutable state cell
--         while _st[1] do
--             _jt[_st[1]](_jt, _st, ...)
--         end
--     end
--
-- Notes:
--   • The opcode pool is shuffled with a Fisher-Yates variant seeded from
--     os.clock()/tick() so values differ every run.
--   • For return statements the handler sets _st[1] = nil and calls a
--     _ret cell so the outer while loop can propagate the return value.
--   • Only local function declarations are transformed (same scope as
--     StatementFlattener's FlattenFunctions target) to avoid mutating
--     top-level module structure.
--   • A Threshold setting (0-1) controls what fraction of eligible functions
--     are transformed, letting you trade obfuscation strength for output size.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")
local visitast = require("ZukaTech.visitast")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local DynamicJumps       = Step:extend()
DynamicJumps.Description = "Replaces function bodies with runtime-randomized indirect jump tables: opcode values and dispatch structure differ every execution, making static CFG analysis impossible."
DynamicJumps.Name        = "Dynamic Jumps"

DynamicJumps.SettingsDescriptor = {
    Threshold = {
        name        = "Threshold",
        description = "Fraction of eligible local functions to transform (0-1)",
        type        = "number",
        default     = 0.85,
        min         = 0,
        max         = 1,
    },
    PoolSize = {
        name        = "PoolSize",
        description = "Size of the opcode pool to shuffle. Larger = more entropy, slightly bigger output.",
        type        = "number",
        default     = 64,
        min         = 16,
        max         = 256,
    },
    MinStatements = {
        name        = "MinStatements",
        description = "Minimum number of statements in a function body to apply the transform.",
        type        = "number",
        default     = 2,
        min         = 1,
        max         = 32,
    },
}

function DynamicJumps:init(settings) end

-- ── helpers ──────────────────────────────────────────────────────────────────

local _parserCache = nil
local function getParser()
    if not _parserCache then
        _parserCache = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    end
    return _parserCache
end

local function parseBlock(src)
    local p   = getParser()
    local ok, result = pcall(function()
        return p:parse(src)
    end)
    if not ok or not result then return nil end
    return result.body.statements
end

local function parseExpr(src)
    local p   = getParser()
    local ok, result = pcall(function()
        return p:parse("return " .. src)
    end)
    if not ok or not result then return nil end
    local stmts = result.body.statements
    if stmts and stmts[1] and stmts[1].values then
        return stmts[1].values[1]
    end
    return nil
end

-- ── code generation ──────────────────────────────────────────────────────────

-- Build the runtime pool-shuffle + opcode-slot-assign preamble.
-- poolSize: total pool size (>= nStmts+2 for some headroom)
-- nSlots:   number of opcode slots needed (one per statement + sentinel)
-- slotVars: list of variable name strings _s1.._sN
local function buildPoolPreamble(poolSize, nSlots, slotVars)
    -- The pool is a table of poolSize unique integers in range 1..poolSize*4.
    -- We shuffle it at runtime with Fisher-Yates.  The first nSlots entries
    -- become the opcode values for statement slots.
    local lines = {}

    -- Pool initialisation: sequential values that get shuffled
    local poolLit = "{"
    for i = 1, poolSize do
        poolLit = poolLit .. (i * 3 + 7)  -- arbitrary non-sequential base values
        if i < poolSize then poolLit = poolLit .. "," end
    end
    poolLit = poolLit .. "}"

    lines[#lines+1] = "local _pool = " .. poolLit
    -- Fisher-Yates using os.clock/tick seed
    lines[#lines+1] = "do"
    lines[#lines+1] = "  local _sd = math.floor(((tick and tick()) or (os and os.clock and os.clock()) or 0.9876) * 999983) % 2147483647 + 1"
    lines[#lines+1] = "  local _sz = " .. poolSize
    lines[#lines+1] = "  for _fi = _sz, 2, -1 do"
    lines[#lines+1] = "    _sd = (_sd * 1664525 + 1013904223) % 2147483648"
    lines[#lines+1] = "    local _fj = (_sd % _fi) + 1"
    lines[#lines+1] = "    _pool[_fi], _pool[_fj] = _pool[_fj], _pool[_fi]"
    lines[#lines+1] = "  end"
    lines[#lines+1] = "end"

    -- Assign opcode slot variables from first nSlots pool entries
    for i, vname in ipairs(slotVars) do
        lines[#lines+1] = "local " .. vname .. " = _pool[" .. i .. "]"
    end

    return table.concat(lines, "\n")
end

-- ── unparse a single statement to Lua source ─────────────────────────────────
-- We use the pipeline's unparser if available, otherwise fall back to a
-- simple serialisation via the ast's own source tracking.
-- Since we can't easily call the unparser here (circular dependency risk),
-- we instead keep statements as AST nodes and inject them directly.

-- ── transform a function body ─────────────────────────────────────────────────

-- Returns a new list of AST statements that implement the indirect jump table
-- transformation, or nil if transformation is not possible.
local function transformBody(stmts, poolSize, scope)
    local n = #stmts
    if n < 1 then return nil end

    -- We cannot handle statements we can't clone/reference, so do a quick
    -- sanity check: if any statement is itself a FunctionDeclaration that
    -- defines a name we'd shadow, skip (conservative).
    -- For now we accept all statements.

    -- Build slot variable names
    local slotVars = {}
    for i = 1, n do
        slotVars[i] = "_dj_s" .. i .. "_" .. math.random(1000, 9999)
    end
    local sentinelVar = "_dj_nil_" .. math.random(1000, 9999)

    -- Build the pool preamble source
    local actualPoolSize = math.max(poolSize, n + 8)
    local allVars = {}
    for _, v in ipairs(slotVars) do allVars[#allVars+1] = v end
    allVars[#allVars+1] = sentinelVar

    local preambleSrc = buildPoolPreamble(actualPoolSize, n + 1, allVars)

    -- Build the jump table: _jt is a local table; each slot is a function
    -- _jt[_s_i] = function(_jt_, _st_) <stmt_i>; _st_[1] = _s_{i+1} end
    -- Last slot sets _st_[1] = nil (sentinel) to terminate.
    local jtLines = {}
    jtLines[#jtLines+1] = "local _djt = {}"

    for i = 1, n do
        local nextSlot
        if i < n then
            nextSlot = slotVars[i + 1]
        else
            nextSlot = "nil"
        end
        -- We cannot inline the AST statement as source text easily, so we
        -- build a wrapper that holds the statement reference.
        -- We will build placeholder functions and then splice in the real
        -- statement AST nodes after parsing the structural shell.
        jtLines[#jtLines+1] = string.format(
            "_djt[%s] = function(_djt_, _djst_) _djst_[1] = %s end",
            slotVars[i], nextSlot
        )
    end

    -- State cell and dispatch loop
    jtLines[#jtLines+1] = "local _djst = { " .. slotVars[1] .. " }"
    jtLines[#jtLines+1] = "while _djst[1] do _djt[_djst[1]](_djt, _djst) end"

    -- Parse the structural shell
    local fullSrc = preambleSrc .. "\n" .. table.concat(jtLines, "\n")
    local parsed  = parseBlock(fullSrc)
    if not parsed then return nil end

    -- Now we need to splice the original statements into the handler functions.
    -- The handler functions are AssignmentStatements: _djt[_s_i] = function(...) ... end
    -- We find them by index: preamble produces some statements, then n assignment statements.
    -- Count preamble statements by re-parsing just the preamble.
    local preambleParsed = parseBlock(preambleSrc)
    if not preambleParsed then return nil end
    local preambleCount  = #preambleParsed

    -- The next n statements in `parsed` are the _djt[...] = function assignments.
    -- Each has .values[1] which is a FunctionExpression whose .body.statements
    -- contains exactly one statement: _djst[1] = nextSlot.
    -- We prepend the original stmt[i] before that assignment.
    for i = 1, n do
        local assignIdx = preambleCount + i
        local assignNode = parsed[assignIdx]
        if not assignNode then return nil end  -- parsing mismatch, bail

        -- Find the function expression on the RHS
        local funcExpr = nil
        if assignNode.kind == AstKind.AssignmentStatement then
            -- _djt[key] = function(...)
            if assignNode.values and assignNode.values[1] then
                funcExpr = assignNode.values[1]
            end
        end
        if not funcExpr then return nil end

        local bodyStmts = funcExpr.body and funcExpr.body.statements
        if not bodyStmts then return nil end

        -- Insert the original statement at the front
        table.insert(bodyStmts, 1, stmts[i])
    end

    return parsed
end

-- ── apply ────────────────────────────────────────────────────────────────────

function DynamicJumps:apply(ast, pipeline)
    local threshold    = self.Threshold or 0.85
    local poolSize     = math.floor(self.PoolSize or 64)
    local minStmts     = math.floor(self.MinStatements or 2)

    visitast(ast, nil, function(node, data)
        -- Target: LocalStatement that assigns a FunctionExpression
        -- (i.e., `local function f(...) ... end` desugars to
        --  `local f; f = function(...) ... end` or is represented as
        --  AstKind.LocalFunctionDeclaration / AstKind.FunctionDeclaration)
        local isFuncDecl = (node.kind == AstKind.FunctionDeclaration or
                            node.kind == AstKind.LocalFunctionDeclaration)

        if not isFuncDecl then return end
        if math.random() > threshold then return end

        local body = node.body
        if not body then return end
        local stmts = body.statements
        if not stmts or #stmts < minStmts then return end

        local newStmts = transformBody(stmts, poolSize, body.scope)
        if newStmts then
            -- Replace the body's statement list with the transformed one
            body.statements = newStmts
        end
    end)

    return ast
end

return DynamicJumps
