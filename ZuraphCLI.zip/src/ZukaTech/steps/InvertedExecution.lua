local Step = require("ZukaTech.step")
local Ast = require("ZukaTech.ast")
local Scope = require("ZukaTech.scope")
local AstKind = Ast.AstKind

local InvertedExecution = Step:extend()
InvertedExecution.Name = "Inverted Execution"
InvertedExecution.Description = "Physically flips the script so the last chunk appears first in the file; logical execution order is preserved via a bottom-anchored state machine dispatcher."

InvertedExecution.SettingsDescriptor = {
    ChunkSize = {
        type = "number",
        default = 1,
        min = 1,
        max = 20,
    },
    RandomiseIds = {
        type = "boolean",
        default = true,
    },
    JunkChunks = {
        type = "number",
        default = 3,
        min = 0,
        max = 20,
    },
}

function InvertedExecution:init(settings) end

local usedIds = {}
local function freshId(randomise)
    local id
    repeat
        if randomise then
            id = math.random(100000, 999999)
        else
            id = math.random(10000, 99999)
        end
    until not usedIds[id]
    usedIds[id] = true
    return id
end

local function resetIds()
    usedIds = {}
end

-- The unparser's inter-statement and pre-'end' separator logic
-- (whitespaceIfNeeded2) only emits a space when the preceding token ends
-- in an ident char.  Number literals end in a digit, which is NOT an ident
-- char, so adjacent statements or the closing 'end' get merged into the
-- number token (e.g. "123456local" or "123456end"), breaking Lua's parser.
--
-- Fix: wrap the entire handler body in a DoStatement.  A DoStatement always
-- ends in the keyword "end", whose last character 'd' IS an ident char, so
-- the outer function's closing "end" is always correctly separated.
-- All user statements and the return live inside the inner do..end, which
-- the Lua parser handles without any ambiguity.
local function makeHandlerFunc(innerStmts, nextId, parentScope)
    local funcScope = Scope:new(parentScope)
    local doScope   = Scope:new(funcScope)
    local retId     = doScope:addVariable()

    local doBody = {}
    for _, s in ipairs(innerStmts) do
        table.insert(doBody, s)
    end
    table.insert(doBody,
        Ast.LocalVariableDeclaration(
            doScope,
            { retId },
            { Ast.NumberExpression(nextId) }
        )
    )
    table.insert(doBody,
        Ast.ReturnStatement({ Ast.VariableExpression(doScope, retId) })
    )

    -- The function body is a single DoStatement; it always ends in "end"
    local funcBody = Ast.Block({
        Ast.DoStatement(Ast.Block(doBody, doScope))
    }, funcScope)

    return Ast.FunctionLiteralExpression({ Ast.VarargExpression() }, funcBody)
end

function InvertedExecution:apply(ast)
    local statements = ast.body.statements
    if not statements or #statements == 0 then return end

    resetIds()

    local chunkSize  = self.ChunkSize
    local randomise  = self.RandomiseIds
    local junkCount  = self.JunkChunks
    local terminate  = 0
    local rootScope  = ast.body.scope

    local chunks = {}
    local cur = {}
    for i, stmt in ipairs(statements) do
        table.insert(cur, stmt)
        if #cur >= chunkSize or i == #statements then
            table.insert(chunks, cur)
            cur = {}
        end
    end

    local n = #chunks
    local realIds = {}
    for i = 1, n do
        realIds[i] = freshId(randomise)
    end

    local tableEntries = {}
    local function addJunkEntry()
        local jId  = freshId(randomise)
        local func = makeHandlerFunc({}, terminate, rootScope)
        table.insert(tableEntries,
            Ast.KeyedTableEntry(Ast.NumberExpression(jId), func))
    end

    local junkBudget = junkCount
    local function maybeJunk()
        if junkBudget > 0 and math.random() < 0.55 then
            addJunkEntry()
            junkBudget = junkBudget - 1
        end
    end

    for i = n, 1, -1 do
        maybeJunk()
        local nextId = realIds[i + 1] or terminate
        local func   = makeHandlerFunc(chunks[i], nextId, rootScope)
        table.insert(tableEntries,
            Ast.KeyedTableEntry(Ast.NumberExpression(realIds[i]), func))
    end

    while junkBudget > 0 do
        addJunkEntry()
        junkBudget = junkBudget - 1
    end

    local function rvar(prefix)
        local s = ""
        local charset = "abcdefghijklmnopqrstuvwxyz"
        for _ = 1, 7 do
            local idx = math.random(1, #charset)
            s = s .. charset:sub(idx, idx)
        end
        return prefix .. s
    end

    local dispId  = rootScope:addVariable(rvar("_D"))
    local stateId = rootScope:addVariable(rvar("_S"))

    local newStmts = {}

    table.insert(newStmts,
        Ast.LocalVariableDeclaration(
            rootScope,
            { dispId },
            { Ast.TableConstructorExpression(tableEntries) }
        )
    )

    table.insert(newStmts,
        Ast.LocalVariableDeclaration(
            rootScope,
            { stateId },
            { Ast.NumberExpression(realIds[1]) }
        )
    )

    local dispatchCall = Ast.FunctionCallExpression(
        Ast.IndexExpression(
            Ast.VariableExpression(rootScope, dispId),
            Ast.VariableExpression(rootScope, stateId)
        ),
        {}
    )

    local loopBody = Ast.Block({
        Ast.AssignmentStatement(
            { Ast.AssignmentVariable(rootScope, stateId) },
            { dispatchCall }
        )
    }, rootScope)

    local loopCond = Ast.NotEqualsExpression(
        Ast.VariableExpression(rootScope, stateId),
        Ast.NumberExpression(terminate)
    )

    table.insert(newStmts, Ast.WhileStatement(loopBody, loopCond))

    ast.body.statements = newStmts
end

return InvertedExecution