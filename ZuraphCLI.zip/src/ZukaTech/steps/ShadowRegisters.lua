-- This Script is Part of the ZukaTech Obfuscator
--
-- ShadowRegisters.lua
--
-- Implements the "AlternativeStack" pattern observed in Luraph:
--   • Injects a secondary table (the "shadow stack") at the top of the script.
--   • A random fraction of local variable assignments are mirrored through
--     the shadow table: instead of storing directly in the local, the value
--     is stored in shadowTbl[key] and then read back.
--   • This creates two parallel data flows for the same value, confusing
--     dataflow-based decompilers and making register tracing harder.
--   • The shadow table is keyed with randomised integer indices so the
--     pattern does not produce a fingerprint.
--   • Fully Lua 5.1 / Luau compatible.

local Step          = require("ZukaTech.step")
local Ast           = require("ZukaTech.ast")
local Scope         = require("ZukaTech.scope")
local Parser        = require("ZukaTech.parser")
local Enums         = require("ZukaTech.enums")
local visitast      = require("ZukaTech.visitast")
local RandomStrings = require("ZukaTech.randomStrings")
local util          = require("ZukaTech.util")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local ShadowRegisters       = Step:extend()
ShadowRegisters.Description = "Mirrors a random fraction of variable assignments through a secondary 'shadow' table (Luraph AlternativeStack pattern). Creates dual data-flow paths that confuse decompiler register tracing."
ShadowRegisters.Name        = "Shadow Registers"

ShadowRegisters.SettingsDescriptor = {
    Density = {
        name        = "Density",
        description = "Fraction of local variable declarations to mirror (0–1)",
        type        = "number",
        default     = 0.4,
        min         = 0,
        max         = 1,
    },
    ShadowSize = {
        name        = "ShadowSize",
        description = "Number of pre-allocated shadow slots (8–64). Determines key range.",
        type        = "number",
        default     = 24,
        min         = 8,
        max         = 64,
    },
}

function ShadowRegisters:init(settings) end

-- ── apply ─────────────────────────────────────────────────────────────────────

function ShadowRegisters:apply(ast, pipeline)
    local density    = math.max(0, math.min(1, self.Density or 0.4))
    local shadowSize = math.max(8, math.min(64, math.floor(self.ShadowSize or 24)))

    -- Root scope variable for the shadow table
    local rootScope   = ast.body.scope
    local shadowVar   = rootScope:addVariable()
    local shadowName  = "_shd_" .. RandomStrings.randomString(6)

    -- Pre-allocate a pool of shadow keys (random ints, no repeats)
    local keyPool = {}
    local usedKeys = {}
    while #keyPool < shadowSize do
        local k = math.random(1, shadowSize * 4)
        if not usedKeys[k] then
            usedKeys[k] = true
            table.insert(keyPool, k)
        end
    end
    local nextKeyIdx = 1
    local function nextKey()
        local k = keyPool[nextKeyIdx]
        nextKeyIdx = nextKeyIdx + 1
        if nextKeyIdx > #keyPool then nextKeyIdx = 1 end
        return k
    end

    -- Build the shadow table declaration:
    --   local <shadowVar> = {}
    local shadowDecl = Ast.LocalVariableDeclaration(
        rootScope,
        { shadowVar },
        { Ast.TableConstructorExpression({}) }
    )

    -- Walk the AST and mirror qualifying local variable declarations.
    -- For a statement like:   local x = expr
    -- We emit two statements:
    --   shadowTbl[K] = expr
    --   local x      = shadowTbl[K]
    -- This gives decompilers two paths to the same value.

    local transformed = 0

    visitast(ast, nil, function(node, data)
        if node.kind ~= AstKind.LocalVariableDeclaration then return end
        -- Only mirror single-variable, single-expression declarations
        -- (multi-assign is more complex and we don't want to break it)
        if #node.ids ~= 1 or #node.expressions ~= 1 then return end
        if math.random() > density then return end

        local varId   = node.ids[1]
        local expr    = node.expressions[1]
        local key     = nextKey()
        local scope   = data.scope  -- the scope containing this declaration

        -- Make sure scope can reference the shadow table
        scope:addReferenceToHigherScope(rootScope, shadowVar)

        -- Build:  shadowTbl[key] = expr
        local writeStmt = Ast.AssignmentStatement(
            {
                Ast.AssignmentIndexing(
                    Ast.VariableExpression(rootScope, shadowVar),
                    Ast.NumberExpression(key)
                )
            },
            { expr }
        )

        -- Replace the rhs of the original declaration with the shadow read:
        --   local x = shadowTbl[key]
        node.expressions[1] = Ast.IndexExpression(
            Ast.VariableExpression(rootScope, shadowVar),
            Ast.NumberExpression(key)
        )

        -- We need to INSERT writeStmt BEFORE node.  visitast doesn't give us
        -- block-level insertion easily, so we wrap both into a do block and
        -- replace the node with the do block.  However, visitast returns a
        -- replacement node, so we return a DoStatement containing both stmts.
        --
        -- Actually the cleanest approach: return a Block wrapped in a DoStatement.
        -- The parent will see a DoStatement instead of the LocalVariableDeclaration.
        local innerScope = Scope:new(scope)
        innerScope:addReferenceToHigherScope(rootScope, shadowVar)

        transformed = transformed + 1

        return Ast.DoStatement(Ast.Block({
            writeStmt,
            node,
        }, innerScope))
    end)

    -- Inject shadow table declaration at the very top
    table.insert(ast.body.statements, 1, shadowDecl)

    return ast
end

return ShadowRegisters
