-- namegenerators/zukaweave.lua
-- ZukaWeave — by Zuka
--
-- Every variable name is built by weaving a signature string into a
-- deterministic but shuffled charset. The signature characters dominate
-- the output so your tag is dissolved into every single name.
--
-- Someone deobfuscating will find the signature EVERYWHERE.
-- They can't remove it without rewriting every variable — and even then
-- it's structural, not cosmetic.

local util = require("ZukaTech.util")

-- ── CONFIG ────────────────────────────────────────────────────────────────────

local SIGNATURE      = "GrillMasterXBBQ"   -- woven into every name
local WEAVE_STRENGTH = 0.55            -- 0.0 = signature rarely appears, 1.0 = signature only
local MIN_LENGTH     = 4               -- minimum name length
local MAX_LENGTH     = 9               -- maximum name length

-- ── INTERNALS ─────────────────────────────────────────────────────────────────

-- Build signature charset: both cases of each unique letter in SIGNATURE
local sigChars  = {}
local sigLookup = {}
for i = 1, #SIGNATURE do
    local c = SIGNATURE:sub(i, i)
    local l = c:lower()
    local u = c:upper()
    if not sigLookup[l] then
        sigLookup[l] = true
        sigLookup[u] = true
        table.insert(sigChars, l)
        table.insert(sigChars, u)
    end
end

-- Filler charset: everything NOT in the signature
local fillChars = {}
for c in ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"):gmatch(".") do
    if not sigLookup[c] and c ~= "_" then
        table.insert(fillChars, c)
    end
end

-- Valid start chars (no digits or underscore)
local startSigChars  = {}
local startFillChars = {}
for _, c in ipairs(sigChars) do
    if not c:match("%d") and c ~= "_" then
        table.insert(startSigChars, c)
    end
end
for _, c in ipairs(fillChars) do
    if not c:match("%d") and c ~= "_" then
        table.insert(startFillChars, c)
    end
end

local seed        = 0
local sigOrder    = {}
local fillOrder   = {}
local startSigO   = {}
local startFillO  = {}

-- Deterministic pseudo-random from id + seed (Lua 5.1 compatible, no bitwise ops)
local function xor32(a, b)
    local result = 0
    local bit    = 1
    for i = 1, 32 do
        local ab = a % 2
        local bb = b % 2
        if ab ~= bb then result = result + bit end
        a   = math.floor(a / 2)
        b   = math.floor(b / 2)
        bit = bit * 2
    end
    return result
end

local function shr(x, n)
    return math.floor(x / (2 ^ n))
end

local function prng(id)
    local x = (id * 2246822519 + seed * 2654435761) % 0x100000000
    x = xor32(x, shr(x, 15))
    x = (x * 2246822519) % 0x100000000
    x = xor32(x, shr(x, 13))
    x = (x * 3266489917) % 0x100000000
    x = xor32(x, shr(x, 16))
    return x
end

-- Pick a character: biased toward sig chars based on WEAVE_STRENGTH
local function pickChar(id, pos, isStart)
    local r     = prng(id * 31 + pos * 7) / 0x100000000
    local useSig = r < WEAVE_STRENGTH

    if isStart then
        if useSig and #startSigO > 0 then
            return startSigChars[startSigO[(prng(id + pos) % #startSigO) + 1]]
        else
            return startFillChars[startFillO[(prng(id + pos) % #startFillO) + 1]]
        end
    else
        if useSig and #sigOrder > 0 then
            return sigChars[sigOrder[(prng(id + pos * 3) % #sigOrder) + 1]]
        else
            return fillChars[fillOrder[(prng(id + pos * 3) % #fillOrder) + 1]]
        end
    end
end

local function generateName(id, scope)
    -- Length varies deterministically per id
    local length = MIN_LENGTH + (prng(id) % (MAX_LENGTH - MIN_LENGTH + 1))
    local name   = ""

    -- First char (no digits/underscore)
    name = name .. pickChar(id, 0, true)

    -- Remaining chars — weave in signature letters
    for i = 1, length - 1 do
        name = name .. pickChar(id, i, false)
    end

    -- Force at least one guaranteed signature character somewhere in the middle
    -- This ensures the tag is ALWAYS present regardless of WEAVE_STRENGTH
    local forcePos = 1 + (prng(id * 13) % (length - 1))
    local forceChr = sigChars[sigOrder[(prng(id) % #sigOrder) + 1]]
    name = name:sub(1, forcePos) .. forceChr .. name:sub(forcePos + 2)

    return name
end

local function prepare(ast)
    seed = math.random(0, 0xFFFFFF)

    -- Shuffle all index orders so each run produces different name sequences
    sigOrder = {}
    for i = 1, #sigChars do sigOrder[i] = i end
    util.shuffle(sigOrder)

    fillOrder = {}
    for i = 1, #fillChars do fillOrder[i] = i end
    util.shuffle(fillOrder)

    startSigO = {}
    for i = 1, #startSigChars do startSigO[i] = i end
    util.shuffle(startSigO)

    startFillO = {}
    for i = 1, #startFillChars do startFillO[i] = i end
    util.shuffle(startFillO)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
